#include "TitanS_hcsr04.h"
#include "Arduino.h"


TitanS_hcsr04::TitanS_hcsr04(int echo_pin,int trig_pin)
{
    pinMode(echo_pin,INPUT);
    pinMode(trig_pin,OUTPUT);
    _echo_pin=echo_pin;
    _trig_pin=trig_pin;
}

void TitanS_hcsr04::start()
{
  int sure;
  digitalWrite(_trig_pin,LOW);
  delayMicroseconds(2);
  digitalWrite(_trig_pin,HIGH);
  delayMicroseconds(10);
  digitalWrite(_trig_pin,LOW);
  sure=pulseIn(_echo_pin,HIGH);
  distance=(sure*.0343)/2;
}