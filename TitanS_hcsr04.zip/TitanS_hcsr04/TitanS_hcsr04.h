#ifndef TitanS_hcsr04_h
#define TitanS_hcsr04_h

#include "Arduino.h"

class TitanS_hcsr04
{
    public:
    TitanS_hcsr04(int echo_pin,int trig_pin);
    void start();
    int distance;
    private:
    int _echo_pin;
    int _trig_pin;
};
#endif

